import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
from datetime import datetime
import os

# Настройки подключения к БД
DB_CONFIG = {
    "host": "172.26.112.1",  # Ваш IP из resolv.conf
    "port": 5432,
    "dbname": "postgres",
    "user": "postgres",
    "password": "C4v3m6a3K5S8"
}

# Конфигурация: какие файлы в какие таблицы грузить
TABLES_CONFIG = {
    'deal_info.csv': {
        'table_name': 'rd.deal_info',
        'columns': ['deal_rk','deal_num','deal_name','deal_sum','client_rk','account_rk','agreement_rk','deal_start_date','department_rk','product_rk','deal_type_cd','effective_from_date','effective_to_date']
    },
    'dict_currency.csv': {
        'table_name': 'rd.dict_currency',
        'columns': ['currency_cd','currency_name','effective_from_date','effective_to_date']
    },
    'product.csv': {
        'table_name': 'rd.product',
        'columns': ['product_rk','product_name','effective_from_date','effective_to_date']
    }
}

def load_csv_to_table(csv_filename, table_name, columns):
    csv_path = f"/home/lenovo/airflow/data/{csv_filename}"
    
    conn = None
    cur = None
    
    try:
        # Чтение CSV
        df = pd.read_csv(csv_path, sep=',', encoding='cp1251')
        
        # 🔍 ДЕТАЛЬНАЯ ДИАГНОСТИКА
        print(f"\n📊 АНАЛИЗ ФАЙЛА {csv_filename}:")
        print(f"Количество колонок в CSV (по факту): {len(df.columns)}")
        print(f"Названия колонок в CSV: {list(df.columns)}")
        print(f"Количество колонок в списке columns: {len(columns)}")
        print(f"Список columns: {columns}")
        
        # Проверка на скрытые символы
        for i, col in enumerate(df.columns):
            if col != col.strip():
                print(f"⚠️  Колонка {i} имеет пробелы: '{repr(col)}'")
        
        print(f"✅ Прочитано {len(df)} строк из {csv_filename}\n")
        
        # Подключение к БД
        conn = psycopg2.connect(**DB_CONFIG)
        cur = conn.cursor()
        
        # Проверка структуры таблицы
        cur.execute("""
            SELECT column_name, data_type 
            FROM information_schema.columns 
            WHERE table_schema = 'rd' AND table_name = %s
            ORDER BY ordinal_position
        """, (table_name.split('.')[-1],))
        
        table_columns = cur.fetchall()
        print(f"📊 СТРУКТУРА ТАБЛИЦЫ {table_name}:")
        print(f"Количество колонок в таблице: {len(table_columns)}")
        for col_name, data_type in table_columns:
            print(f"  - {col_name} ({data_type})")
        print()
        
        # Очистка таблицы
        cur.execute(f"TRUNCATE TABLE {table_name}")
        conn.commit()
        
        # Вставка данных
        df = df.where(pd.notnull(df), None)
        cols_str = ", ".join(columns)
        
        print(f"📝 SQL запрос: INSERT INTO {table_name} ({cols_str}) VALUES %s")
        print(f"Количество значений для вставки: {len(columns)}")
        print()
        
        values = [tuple(x) for x in df.to_numpy()]
        insert_sql = f"INSERT INTO {table_name} ({cols_str}) VALUES %s"
        
        execute_values(cur, insert_sql, values)
        conn.commit()
        
        print(f"✅ Загружено {len(df)} строк в {table_name}")
        
    except Exception as e:
        print(f"❌ Ошибка загрузки {csv_filename}: {e}")
        raise
    finally:
        if cur:
            cur.close()
        if conn:
            conn.close()

def load_all_tables():
    """
    Загружает ВСЕ таблицы по очереди
    """
    print("🚀 Запуск загрузки CSV файлов в RD слой...")
    
    # ✅ ЗДЕСЬ мы перебираем файлы и для каждого вызываем функцию
    for csv_filename, config in TABLES_CONFIG.items():
        load_csv_to_table(
            csv_filename=csv_filename,  # ← вот откуда берется переменная!
            table_name=config['table_name'],
            columns=config['columns']
        )
    
    print("✅ Все файлы загружены!")

# Точка входа
if __name__ == "__main__":
    load_all_tables()