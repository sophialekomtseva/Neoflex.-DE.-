import psycopg2
from datetime import datetime
import os

DB_CONFIG = {
    "host": "172.26.112.1",
    "port": 5432,
    "dbname": "postgres",
    "user": "postgres",
    "password": "C4v3m6a3K5S8"  # ЗАМЕНИТЕ на ваш пароль
}

def refresh_loan_holiday():
    """Пересчет витрины loan_holiday_info"""
    print("🔄 Запуск пересчета витрины loan_holiday_info...")
    
    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()
    
    try:
        # Логирование начала
        start_time = datetime.now()
        cur.execute("""
            INSERT INTO logs.etl_log (process_name, status, start_time)
            VALUES (%s, %s, %s)
        """, ('refresh_loan_holiday', 'START', start_time))
        conn.commit()
        
        # Чтение и выполнение SQL-скрипта
        sql_path = '/home/lenovo/airflow/sql/refresh_loan_holiday_info.sql'
        with open(sql_path, 'r', encoding='utf-8') as f:
            sql_script = f.read()
        
        print("📝 Выполнение SQL-скрипта...")
        cur.execute(sql_script)
        conn.commit()
        
        # Подсчет результата
        cur.execute("SELECT COUNT(*) FROM dm.loan_holiday_info")
        rows_count = cur.fetchone()[0]
        
        # Логирование успеха
        end_time = datetime.now()
        cur.execute("""
            UPDATE logs.etl_log 
            SET status = %s, 
                end_time = %s,
                rows_loaded = %s
            WHERE process_name = %s 
            AND status = 'START'
        """, ('SUCCESS', end_time, rows_count, 'refresh_loan_holiday'))
        conn.commit()
        
        print(f"✅ Витрина пересчитана! Загружено {rows_count} строк")
        print(f"⏱️ Время выполнения: {end_time - start_time}")
        
        return rows_count
        
    except Exception as e:
        conn.rollback()
        print(f"❌ Ошибка пересчета витрины: {e}")
        
        # Логирование ошибки
        cur.execute("""
            UPDATE logs.etl_log 
            SET status = %s, 
                end_time = %s,
                error_message = %s
            WHERE process_name = %s 
            AND status = 'START'
        """, ('FAILED', datetime.now(), str(e), 'refresh_loan_holiday'))
        conn.commit()
        raise
        
    finally:
        cur.close()
        conn.close()

if __name__ == "__main__":
    refresh_loan_holiday()