from airflow import DAG # type: ignore
from airflow.operators.python import PythonOperator # type: ignore
from airflow.operators.bash import BashOperator # type: ignore
from datetime import datetime, timedelta
import sys

# Добавляем путь к проекту
sys.path.append('/home/lenovo/airflow')

from scripts.load_csv_to_rd import load_all_tables # type: ignore
from scripts.refresh_loan_holiday import refresh_loan_holiday # type: ignore

# Настройки DAG
default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2024, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    'email_on_failure': False,
}

dag = DAG(
    '02_reload_loan_holiday',
    default_args=default_args,
    description='Перезагрузка витрины loan_holiday_info',
    schedule_interval=None,  # Запуск по требованию
    catchup=False,
    tags=['etl', 'loan_holiday'],
)

# Task 1: Загрузка CSV в RD слой
load_csv_task = PythonOperator(
    task_id='load_csv_to_rd_layer',
    python_callable=load_all_tables,
    dag=dag,
)

# Task 2: Пересчет витрины
refresh_vitrine_task = PythonOperator(
    task_id='refresh_loan_holiday_vitrine',
    python_callable=refresh_loan_holiday,
    dag=dag,
)

# Task 3: Проверка результата
verify_task = BashOperator(
    task_id='verify_result',
    bash_command="""
    psql -h localhost -U postgres -d postgres -c "
    SELECT 
        'Витрина loan_holiday_info' as table_name,
        COUNT(*) as row_count,
        COUNT(DISTINCT effective_from_date) as unique_dates,
        MIN(effective_from_date) as min_date,
        MAX(effective_from_date) as max_date
    FROM dm.loan_holiday_info
    UNION ALL
    SELECT 
        'RD.deal',
        COUNT(*),
        COUNT(DISTINCT effective_from_date),
        MIN(effective_from_date),
        MAX(effective_from_date)
    FROM rd.deal
    "
    """,
    dag=dag,
)

# Task 4: Проверка логов
check_logs_task = BashOperator(
    task_id='check_etl_logs',
    bash_command="""
    psql -h localhost -U postgres -d postgres -c "
    SELECT 
        process_name,
        status,
        start_time,
        end_time,
        rows_loaded,
        EXTRACT(EPOCH FROM (end_time - start_time)) as duration_sec
    FROM logs.etl_log 
    WHERE process_name = 'refresh_loan_holiday'
    ORDER BY start_time DESC
    LIMIT 5
    "
    """,
    dag=dag,
)

# Определение последовательности задач
load_csv_task >> refresh_vitrine_task >> verify_task >> check_logs_task